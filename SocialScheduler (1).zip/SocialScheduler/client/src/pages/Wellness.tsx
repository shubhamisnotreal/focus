import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Link, useLocation } from 'wouter';
import { 
  Clock, 
  BarChart3, 
  Settings as SettingsIcon, 
  ListTodo as TasksIcon,
  ArrowLeft,
  Search,
  Heart,
  Radio,
  PlayCircle,
  Sparkles
} from 'lucide-react';
import VideoCard from '@/components/VideoCard';
import PlaylistCard from '@/components/PlaylistCard';
import { useYouTubeSearch, useYouTubePlaylists, useYouTubeLiveStreams, useYouTubeCategories, useHealthVideos } from '@/hooks/useYouTube';
import type { YouTubeVideo, YouTubePlaylist } from '@shared/schema';

export default function Wellness() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [activeTab, setActiveTab] = useState('discover');

  const { data: categories } = useYouTubeCategories();
  const { data: searchResults, isLoading: isSearching } = useYouTubeSearch(
    searchQuery, 
    selectedCategory, 
    'video'
  );
  const { data: playlists, isLoading: isLoadingPlaylists } = useYouTubePlaylists();
  const { data: liveStreams, isLoading: isLoadingLive } = useYouTubeLiveStreams();
  const { data: healthVideos, isLoading: isLoadingHealth } = useHealthVideos(
    selectedCategory || 'meditation'
  );

  const handleVideoClick = (video: YouTubeVideo) => {
    window.open(`https://www.youtube.com/watch?v=${video.id}`, '_blank');
  };

  const handlePlaylistClick = (playlist: YouTubePlaylist) => {
    window.open(`https://www.youtube.com/playlist?list=${playlist.id}`, '_blank');
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setActiveTab('search');
  };

  const handleCategorySelect = (categoryKey: string) => {
    setSelectedCategory(categoryKey);
    setActiveTab('discover');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-40">
        <div className="max-w-md mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation('/')}
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <h1 className="text-lg font-semibold text-gray-900">Wellness</h1>
          </div>
          <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-blue-500 rounded-lg flex items-center justify-center">
            <Heart className="w-4 h-4 text-white" />
          </div>
        </div>
      </header>

      {/* Search Bar */}
      <div className="max-w-md mx-auto px-4 py-4">
        <form onSubmit={handleSearch} className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search wellness videos..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </form>
      </div>

      {/* Main Content */}
      <main className="max-w-md mx-auto px-4 pb-20">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="discover" className="text-xs">
              <Sparkles className="w-4 h-4 mr-1" />
              Discover
            </TabsTrigger>
            <TabsTrigger value="search" className="text-xs" disabled={!searchQuery}>
              <Search className="w-4 h-4 mr-1" />
              Search
            </TabsTrigger>
            <TabsTrigger value="playlists" className="text-xs">
              <PlayCircle className="w-4 h-4 mr-1" />
              Playlists
            </TabsTrigger>
            <TabsTrigger value="live" className="text-xs">
              <Radio className="w-4 h-4 mr-1" />
              Live
            </TabsTrigger>
          </TabsList>

          {/* Discover Tab */}
          <TabsContent value="discover" className="space-y-6">
            {/* Health Categories */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Health Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  {categories && Object.entries(categories as Record<string, any>).map(([key, category]) => (
                    <Button
                      key={key}
                      variant={selectedCategory === key ? "default" : "outline"}
                      size="sm"
                      className="h-auto p-3 text-left justify-start"
                      onClick={() => handleCategorySelect(key)}
                    >
                      <div>
                        <div className="font-medium text-sm">{category.name}</div>
                        <div className="text-xs opacity-70 mt-1">
                          {category.queries.length} topics
                        </div>
                      </div>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recommended Videos */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">
                  {selectedCategory ? 
                    (categories as any)?.[selectedCategory]?.name || 'Recommended Videos' : 
                    'Recommended Videos'
                  }
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingHealth ? (
                  <div className="grid grid-cols-1 gap-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="bg-gray-200 animate-pulse rounded-lg aspect-video" />
                    ))}
                  </div>
                ) : healthVideos && Array.isArray(healthVideos) && healthVideos.length > 0 ? (
                  <div className="grid grid-cols-1 gap-4">
                    {healthVideos.slice(0, 6).map((video: YouTubeVideo) => (
                      <VideoCard
                        key={video.id}
                        video={video}
                        onClick={() => handleVideoClick(video)}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Heart className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p className="text-sm">Select a category to discover videos</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Search Tab */}
          <TabsContent value="search" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">
                  Search Results for "{searchQuery}"
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isSearching ? (
                  <div className="grid grid-cols-1 gap-4">
                    {[1, 2, 3, 4].map((i) => (
                      <div key={i} className="bg-gray-200 animate-pulse rounded-lg aspect-video" />
                    ))}
                  </div>
                ) : searchResults && Array.isArray(searchResults) && searchResults.length > 0 ? (
                  <div className="grid grid-cols-1 gap-4">
                    {searchResults.map((video: YouTubeVideo) => (
                      <VideoCard
                        key={video.id}
                        video={video}
                        onClick={() => handleVideoClick(video)}
                      />
                    ))}
                  </div>
                ) : searchQuery ? (
                  <div className="text-center py-8 text-gray-500">
                    <Search className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p className="text-sm">No videos found for "{searchQuery}"</p>
                    <p className="text-xs mt-1">Try searching for meditation, yoga, or wellness</p>
                  </div>
                ) : null}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Playlists Tab */}
          <TabsContent value="playlists" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Curated Wellness Playlists</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingPlaylists ? (
                  <div className="grid grid-cols-1 gap-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="bg-gray-200 animate-pulse rounded-lg aspect-video" />
                    ))}
                  </div>
                ) : playlists && Array.isArray(playlists) && playlists.length > 0 ? (
                  <div className="grid grid-cols-1 gap-4">
                    {playlists.map((playlist: YouTubePlaylist) => (
                      <PlaylistCard
                        key={playlist.id}
                        playlist={playlist}
                        onClick={() => handlePlaylistClick(playlist)}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <PlayCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p className="text-sm">No playlists available</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Live Tab */}
          <TabsContent value="live" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center">
                  <Radio className="w-4 h-4 mr-2 text-red-500" />
                  Live Wellness Streams
                  <Badge variant="secondary" className="ml-2 text-xs">
                    LIVE
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingLive ? (
                  <div className="grid grid-cols-1 gap-4">
                    {[1, 2].map((i) => (
                      <div key={i} className="bg-gray-200 animate-pulse rounded-lg aspect-video" />
                    ))}
                  </div>
                ) : liveStreams && Array.isArray(liveStreams) && liveStreams.length > 0 ? (
                  <div className="grid grid-cols-1 gap-4">
                    {liveStreams.map((stream: YouTubeVideo) => (
                      <VideoCard
                        key={stream.id}
                        video={stream}
                        onClick={() => handleVideoClick(stream)}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Radio className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p className="text-sm">No live streams available</p>
                    <p className="text-xs mt-1">Check back later for live wellness content</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-30">
        <div className="max-w-md mx-auto px-4">
          <div className="flex justify-around py-2">
            <Link href="/">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <Clock className="w-5 h-5 mb-1" />
                <span className="text-xs">Timer</span>
              </div>
            </Link>
            <Link href="/tasks">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <TasksIcon className="w-5 h-5 mb-1" />
                <span className="text-xs">Tasks</span>
              </div>
            </Link>
            <Link href="/wellness">
              <div className="flex flex-col items-center py-2 px-3 text-primary">
                <Heart className="w-5 h-5 mb-1" />
                <span className="text-xs font-medium">Wellness</span>
              </div>
            </Link>
            <Link href="/stats">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <BarChart3 className="w-5 h-5 mb-1" />
                <span className="text-xs">Stats</span>
              </div>
            </Link>
            <Link href="/settings">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <SettingsIcon className="w-5 h-5 mb-1" />
                <span className="text-xs">Settings</span>
              </div>
            </Link>
          </div>
        </div>
      </nav>
    </div>
  );
}