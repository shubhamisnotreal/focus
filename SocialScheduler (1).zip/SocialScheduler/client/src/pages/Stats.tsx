import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link, useLocation } from 'wouter';
import { 
  Clock, 
  BarChart3, 
  Settings as SettingsIcon, 
  ListTodo as TasksIcon,
  ArrowLeft,
  Target,
  Zap,
  Calendar,
  TrendingUp,
  Heart
} from 'lucide-react';
import { useStats } from '@/hooks/useStats';
import { useTasks } from '@/hooks/useTasks';

export default function Stats() {
  const [, setLocation] = useLocation();
  const { stats, isLoading } = useStats();
  const { tasks } = useTasks();

  const completedTasks = tasks.filter(task => task.completed);
  const completionRate = tasks.length > 0 ? Math.round((completedTasks.length / tasks.length) * 100) : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-40">
        <div className="max-w-md mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation('/')}
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <h1 className="text-lg font-semibold text-gray-900">Statistics</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-md mx-auto px-4 pb-20">
        
        {/* Today's Overview */}
        <div className="py-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Today's Overview</h2>
          
          <div className="grid grid-cols-2 gap-3 mb-6">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Target className="w-6 h-6 text-primary" />
                </div>
                <div className="text-2xl font-bold text-gray-900">
                  {stats?.focusSessionsToday || 0}
                </div>
                <div className="text-sm text-gray-500">Focus Sessions</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Zap className="w-6 h-6 text-green-600" />
                </div>
                <div className="text-2xl font-bold text-gray-900">
                  {stats?.tasksCompletedToday || 0}
                </div>
                <div className="text-sm text-gray-500">ListTodo Completed</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Calendar className="w-6 h-6 text-orange-600" />
                </div>
                <div className="text-2xl font-bold text-gray-900">
                  {stats?.currentStreak || 0}
                </div>
                <div className="text-sm text-gray-500">Day Streak</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <TrendingUp className="w-6 h-6 text-blue-600" />
                </div>
                <div className="text-2xl font-bold text-gray-900">
                  {completionRate}%
                </div>
                <div className="text-sm text-gray-500">Completion Rate</div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Detailed Stats */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Focus Time</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm text-gray-600">Total Focus Time</span>
                <span className="font-semibold">
                  {Math.floor((stats?.totalFocusTime || 0) / 60)}h {(stats?.totalFocusTime || 0) % 60}m
                </span>
              </div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm text-gray-600">Average Session</span>
                <span className="font-semibold">
                  {stats?.focusSessionsToday > 0 
                    ? Math.round((stats?.totalFocusTime || 0) / stats.focusSessionsToday)
                    : 0}m
                </span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Task Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm text-gray-600">Total ListTodo</span>
                <span className="font-semibold">{tasks.length}</span>
              </div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm text-gray-600">Completed</span>
                <span className="font-semibold text-green-600">{completedTasks.length}</span>
              </div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm text-gray-600">Remaining</span>
                <span className="font-semibold text-orange-600">{tasks.length - completedTasks.length}</span>
              </div>
              
              {/* Progress Bar */}
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-green-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${completionRate}%` }}
                />
              </div>
            </CardContent>
          </Card>

          {/* Achievement-style cards */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Achievements</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className={`flex items-center p-3 rounded-lg ${
                  (stats?.currentStreak || 0) >= 7 ? 'bg-green-50 border border-green-200' : 'bg-gray-50'
                }`}>
                  <div className="text-2xl mr-3">🔥</div>
                  <div className="flex-1">
                    <div className="font-medium text-sm">Week Warrior</div>
                    <div className="text-xs text-gray-500">Maintain a 7-day streak</div>
                  </div>
                  <div className="text-sm font-semibold text-green-600">
                    {(stats?.currentStreak || 0) >= 7 ? 'Unlocked!' : `${stats?.currentStreak || 0}/7`}
                  </div>
                </div>
                
                <div className={`flex items-center p-3 rounded-lg ${
                  (stats?.focusSessionsToday || 0) >= 4 ? 'bg-green-50 border border-green-200' : 'bg-gray-50'
                }`}>
                  <div className="text-2xl mr-3">🎯</div>
                  <div className="flex-1">
                    <div className="font-medium text-sm">Focus Master</div>
                    <div className="text-xs text-gray-500">Complete 4 focus sessions in a day</div>
                  </div>
                  <div className="text-sm font-semibold text-green-600">
                    {(stats?.focusSessionsToday || 0) >= 4 ? 'Unlocked!' : `${stats?.focusSessionsToday || 0}/4`}
                  </div>
                </div>
                
                <div className={`flex items-center p-3 rounded-lg ${
                  (stats?.tasksCompletedToday || 0) >= 5 ? 'bg-green-50 border border-green-200' : 'bg-gray-50'
                }`}>
                  <div className="text-2xl mr-3">✅</div>
                  <div className="flex-1">
                    <div className="font-medium text-sm">Task Crusher</div>
                    <div className="text-xs text-gray-500">Complete 5 tasks in a day</div>
                  </div>
                  <div className="text-sm font-semibold text-green-600">
                    {(stats?.tasksCompletedToday || 0) >= 5 ? 'Unlocked!' : `${stats?.tasksCompletedToday || 0}/5`}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-30">
        <div className="max-w-md mx-auto px-4">
          <div className="flex justify-around py-2">
            <Link href="/">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <Clock className="w-5 h-5 mb-1" />
                <span className="text-xs">Timer</span>
              </div>
            </Link>
            <Link href="/tasks">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <TasksIcon className="w-5 h-5 mb-1" />
                <span className="text-xs">Tasks</span>
              </div>
            </Link>
            <Link href="/wellness">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <Heart className="w-5 h-5 mb-1" />
                <span className="text-xs">Wellness</span>
              </div>
            </Link>
            <Link href="/stats">
              <div className="flex flex-col items-center py-2 px-3 text-primary">
                <BarChart3 className="w-5 h-5 mb-1" />
                <span className="text-xs font-medium">Stats</span>
              </div>
            </Link>
            <Link href="/settings">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <SettingsIcon className="w-5 h-5 mb-1" />
                <span className="text-xs">Settings</span>
              </div>
            </Link>
          </div>
        </div>
      </nav>
    </div>
  );
}
