import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Link, useLocation } from 'wouter';
import { 
  Clock, 
  BarChart3, 
  Settings as SettingsIcon, 
  ListTodo as TasksIcon,
  Play, 
  Pause, 
  RotateCcw, 
  SkipForward,
  Flag,
  Plus,
  Heart
} from 'lucide-react';
import CircularTimer from '@/components/CircularTimer';
import AddTaskModal from '@/components/AddTaskModal';
import { useTimer } from '@/hooks/useTimer';
import { useTasks } from '@/hooks/useTasks';
import { useStats } from '@/hooks/useStats';
import { TIMER_MODES, TIMER_DURATIONS } from '@/lib/constants';
import { cn } from '@/lib/utils';
import type { Task } from '@shared/schema';

export default function Timer() {
  const [, setLocation] = useLocation();
  const [showAddTask, setShowAddTask] = useState(false);
  
  const currentTask = useTasks().tasks.find(task => !task.completed);
  const { 
    minutes, 
    seconds, 
    isRunning, 
    mode, 
    session,
    toggleTimer, 
    resetTimer, 
    skipTimer, 
    setMode,
    getDisplayTime,
    getProgress 
  } = useTimer(currentTask?.id);
  
  const { tasks, createTask, isCreating } = useTasks();
  const { stats } = useStats();

  const timerModes = [
    { key: TIMER_MODES.FOCUS, label: 'Focus' },
    { key: TIMER_MODES.BREAK, label: 'Break' },
    { key: TIMER_MODES.LONG_BREAK, label: 'Long Break' },
  ];

  const incompleteTasks = tasks.filter(task => !task.completed);
  const displayTasks = incompleteTasks.slice(0, 3); // Show only first 3 tasks

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-40">
        <div className="max-w-md mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Clock className="w-4 h-4 text-white" />
            </div>
            <h1 className="text-lg font-semibold text-gray-900">Focus Flow</h1>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation('/stats')}
            >
              <BarChart3 className="w-4 h-4 text-gray-600" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation('/settings')}
            >
              <SettingsIcon className="w-4 h-4 text-gray-600" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-md mx-auto px-4 pb-20">
        
        {/* Timer Section */}
        <div className="py-8">
          <Card>
            <CardContent className="p-6 text-center">
              
              {/* Timer Mode Selector */}
              <div className="flex bg-gray-100 rounded-xl p-1 mb-6">
                {timerModes.map((timerMode) => (
                  <Button
                    key={timerMode.key}
                    variant="ghost"
                    size="sm"
                    className={cn(
                      "flex-1 text-sm font-medium transition-all duration-200",
                      mode === timerMode.key
                        ? "bg-primary text-white shadow-sm"
                        : "text-gray-600 hover:text-gray-800"
                    )}
                    onClick={() => setMode(timerMode.key)}
                    disabled={isRunning}
                  >
                    {timerMode.label}
                  </Button>
                ))}
              </div>

              {/* Circular Timer */}
              <CircularTimer
                progress={getProgress()}
                size={200}
                strokeWidth={8}
                className="mx-auto mb-6"
              >
                <div className="text-3xl font-bold text-gray-900">
                  {getDisplayTime()}
                </div>
                <div className="text-sm text-gray-500 mt-1">
                  Session {session} of 4
                </div>
              </CircularTimer>

              {/* Timer Controls */}
              <div className="flex items-center justify-center space-x-4">
                <Button
                  variant="outline"
                  size="icon"
                  className="w-12 h-12 rounded-full"
                  onClick={resetTimer}
                  disabled={!isRunning && minutes === TIMER_DURATIONS[mode] && seconds === 0}
                >
                  <RotateCcw className="w-4 h-4" />
                </Button>
                
                <Button
                  size="icon"
                  className="w-16 h-16 rounded-full shadow-lg"
                  onClick={toggleTimer}
                >
                  {isRunning ? (
                    <Pause className="w-6 h-6" />
                  ) : (
                    <Play className="w-6 h-6 ml-1" />
                  )}
                </Button>
                
                <Button
                  variant="outline"
                  size="icon"
                  className="w-12 h-12 rounded-full"
                  onClick={skipTimer}
                  disabled={!isRunning}
                >
                  <SkipForward className="w-4 h-4" />
                </Button>
              </div>

              {/* Current Task Display */}
              {currentTask && (
                <div className="mt-6 p-4 bg-gray-50 rounded-xl">
                  <div className="text-sm text-gray-500 mb-1">Current Task</div>
                  <div className="font-medium text-gray-900">{currentTask.title}</div>
                  <div className="text-xs text-gray-500 mt-1 flex items-center justify-center">
                    <Flag className="w-3 h-3 mr-1 text-yellow-500" />
                    {currentTask.priority} Priority
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">
                {stats?.focusSessionsToday || 0}
              </div>
              <div className="text-xs text-gray-500 mt-1">Focus Sessions</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-accent">
                {stats?.tasksCompletedToday || 0}
              </div>
              <div className="text-xs text-gray-500 mt-1">ListTodo Done</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">
                {stats?.currentStreak || 0}
              </div>
              <div className="text-xs text-gray-500 mt-1">Day Streak</div>
            </CardContent>
          </Card>
        </div>

        {/* Quick ListTodo Preview */}
        <Card>
          <div className="p-4 border-b border-gray-100 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Today's ListTodo</h2>
            <Button
              size="sm"
              className="w-8 h-8 p-0"
              onClick={() => setShowAddTask(true)}
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>

          {displayTasks.length > 0 ? (
            <div className="divide-y divide-gray-50">
              {displayTasks.map((task) => (
                <div key={task.id} className="p-4 flex items-center space-x-3">
                  <div className="w-4 h-4 rounded-full border-2 border-gray-300" />
                  <div className="flex-1">
                    <div className="font-medium text-gray-900 text-sm">
                      {task.title}
                    </div>
                    <div className="text-xs text-gray-500 flex items-center mt-1">
                      <span>{task.category}</span>
                      <Badge 
                        variant="secondary" 
                        className="ml-2 text-xs"
                      >
                        {task.priority}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
              
              {incompleteTasks.length > 3 && (
                <div className="p-4 text-center">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setLocation('/tasks')}
                  >
                    View {incompleteTasks.length - 3} more tasks
                  </Button>
                </div>
              )}
            </div>
          ) : (
            <div className="p-8 text-center text-gray-500">
              <TasksIcon className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p className="text-sm">No tasks for today</p>
              <Button
                variant="ghost"
                size="sm"
                className="mt-2"
                onClick={() => setShowAddTask(true)}
              >
                Add your first task
              </Button>
            </div>
          )}
        </Card>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-30">
        <div className="max-w-md mx-auto px-4">
          <div className="flex justify-around py-2">
            <Link href="/">
              <div className="flex flex-col items-center py-2 px-3 text-primary">
                <Clock className="w-5 h-5 mb-1" />
                <span className="text-xs font-medium">Timer</span>
              </div>
            </Link>
            <Link href="/tasks">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <TasksIcon className="w-5 h-5 mb-1" />
                <span className="text-xs">Tasks</span>
              </div>
            </Link>
            <Link href="/wellness">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <Heart className="w-5 h-5 mb-1" />
                <span className="text-xs">Wellness</span>
              </div>
            </Link>
            <Link href="/stats">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <BarChart3 className="w-5 h-5 mb-1" />
                <span className="text-xs">Stats</span>
              </div>
            </Link>
            <Link href="/settings">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <SettingsIcon className="w-5 h-5 mb-1" />
                <span className="text-xs">Settings</span>
              </div>
            </Link>
          </div>
        </div>
      </nav>

      {/* Add Task Modal */}
      <AddTaskModal
        open={showAddTask}
        onOpenChange={setShowAddTask}
        onSubmit={(taskData) => {
          createTask(taskData);
          setShowAddTask(false);
        }}
        isLoading={isCreating}
      />
    </div>
  );
}
