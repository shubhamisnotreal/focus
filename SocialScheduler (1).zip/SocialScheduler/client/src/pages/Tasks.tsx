import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Link, useLocation } from 'wouter';
import { 
  Clock, 
  BarChart3, 
  Settings as SettingsIcon, 
  ListTodo as TasksIcon,
  Plus,
  Search,
  Filter,
  ArrowLeft,
  Heart
} from 'lucide-react';
import TaskItem from '@/components/TaskItem';
import AddTaskModal from '@/components/AddTaskModal';
import { useTasks } from '@/hooks/useTasks';
import { TASK_CATEGORIES, TASK_PRIORITIES } from '@/lib/constants';
import type { Task } from '@shared/schema';

export default function ListTodo() {
  const [, setLocation] = useLocation();
  const [showAddTask, setShowAddTask] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | undefined>();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');
  const [filterPriority, setFilterPriority] = useState('All');
  
  const { 
    tasks, 
    createTask, 
    updateTask, 
    deleteTask, 
    toggleTask,
    isLoading,
    isCreating,
    isUpdating,
    isToggling
  } = useTasks();

  // Filter tasks
  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         task.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === 'All' || task.category === filterCategory;
    const matchesPriority = filterPriority === 'All' || task.priority === filterPriority;
    
    return matchesSearch && matchesCategory && matchesPriority;
  });

  const completedTasks = filteredTasks.filter(task => task.completed);
  const incompleteTasks = filteredTasks.filter(task => !task.completed);

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setShowAddTask(true);
  };

  const handleSubmitTask = (taskData: any) => {
    if (editingTask) {
      updateTask({ id: editingTask.id, updates: taskData });
    } else {
      createTask(taskData);
    }
    setShowAddTask(false);
    setEditingTask(undefined);
  };

  const handleCloseModal = () => {
    setShowAddTask(false);
    setEditingTask(undefined);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-40">
        <div className="max-w-md mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation('/')}
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <h1 className="text-lg font-semibold text-gray-900">ListTodo</h1>
          </div>
          <Button
            size="sm"
            onClick={() => setShowAddTask(true)}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Task
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-md mx-auto px-4 pb-20">
        
        {/* Search and Filters */}
        <div className="py-4 space-y-3">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search tasks..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          
          {/* Filters */}
          <div className="flex space-x-3">
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="flex-1">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Categories</SelectItem>
                {TASK_CATEGORIES.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger className="flex-1">
                <SelectValue placeholder="Priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Priorities</SelectItem>
                {Object.values(TASK_PRIORITIES).map((priority) => (
                  <SelectItem key={priority} value={priority}>
                    {priority}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* ListTodo Summary */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">
                {incompleteTasks.length}
              </div>
              <div className="text-xs text-gray-500 mt-1">Pending</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">
                {completedTasks.length}
              </div>
              <div className="text-xs text-gray-500 mt-1">Completed</div>
            </CardContent>
          </Card>
        </div>

        {/* Pending ListTodo */}
        {incompleteTasks.length > 0 && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-base">Pending ListTodo</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {incompleteTasks.map((task) => (
                <TaskItem
                  key={task.id}
                  task={task}
                  onToggle={toggleTask}
                  onEdit={handleEditTask}
                  onDelete={deleteTask}
                  isToggling={isToggling}
                />
              ))}
            </CardContent>
          </Card>
        )}

        {/* Completed ListTodo */}
        {completedTasks.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base text-gray-600">
                Completed ListTodo ({completedTasks.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {completedTasks.map((task) => (
                <TaskItem
                  key={task.id}
                  task={task}
                  onToggle={toggleTask}
                  onEdit={handleEditTask}
                  onDelete={deleteTask}
                  isToggling={isToggling}
                />
              ))}
            </CardContent>
          </Card>
        )}

        {/* Empty State */}
        {filteredTasks.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <TasksIcon className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchQuery || filterCategory !== 'All' || filterPriority !== 'All' 
                ? 'No matching tasks' 
                : 'No tasks yet'}
            </h3>
            <p className="text-gray-500 mb-4">
              {searchQuery || filterCategory !== 'All' || filterPriority !== 'All'
                ? 'Try adjusting your search or filters'
                : 'Create your first task to get started with your productivity journey'}
            </p>
            <Button onClick={() => setShowAddTask(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Task
            </Button>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-30">
        <div className="max-w-md mx-auto px-4">
          <div className="flex justify-around py-2">
            <Link href="/">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <Clock className="w-5 h-5 mb-1" />
                <span className="text-xs">Timer</span>
              </div>
            </Link>
            <Link href="/tasks">
              <div className="flex flex-col items-center py-2 px-3 text-primary">
                <TasksIcon className="w-5 h-5 mb-1" />
                <span className="text-xs font-medium">Tasks</span>
              </div>
            </Link>
            <Link href="/wellness">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <Heart className="w-5 h-5 mb-1" />
                <span className="text-xs">Wellness</span>
              </div>
            </Link>
            <Link href="/stats">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <BarChart3 className="w-5 h-5 mb-1" />
                <span className="text-xs">Stats</span>
              </div>
            </Link>
            <Link href="/settings">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <SettingsIcon className="w-5 h-5 mb-1" />
                <span className="text-xs">Settings</span>
              </div>
            </Link>
          </div>
        </div>
      </nav>

      {/* Add/Edit Task Modal */}
      <AddTaskModal
        open={showAddTask}
        onOpenChange={handleCloseModal}
        onSubmit={handleSubmitTask}
        editingTask={editingTask}
        isLoading={isCreating || isUpdating}
      />
    </div>
  );
}
