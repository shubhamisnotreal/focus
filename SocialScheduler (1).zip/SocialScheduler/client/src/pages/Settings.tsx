import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Link, useLocation } from 'wouter';
import { 
  Clock, 
  BarChart3, 
  Settings as SettingsIcon, 
  ListTodo as TasksIcon,
  ArrowLeft,
  Bell,
  Volume2,
  Download,
  Trash2,
  Shield,
  Moon,
  Sun,
  Heart
} from 'lucide-react';
import { useState } from 'react';

export default function Settings() {
  const [, setLocation] = useLocation();
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [sounds, setSounds] = useState(true);
  const [strictMode, setStrictMode] = useState(true);

  const handleExportData = () => {
    // In a real app, this would export user data
    console.log('Exporting data...');
  };

  const handleClearData = () => {
    const confirmed = window.confirm(
      'Are you sure you want to clear all data? This action cannot be undone.'
    );
    if (confirmed) {
      // In a real app, this would clear user data
      console.log('Clearing data...');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-40">
        <div className="max-w-md mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation('/')}
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <h1 className="text-lg font-semibold text-gray-900">Settings</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-md mx-auto px-4 pb-20">
        
        <div className="py-6 space-y-6">
          
          {/* Appearance */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center">
                {darkMode ? <Moon className="w-4 h-4 mr-2" /> : <Sun className="w-4 h-4 mr-2" />}
                Appearance
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="dark-mode" className="text-sm">Dark Mode</Label>
                <Switch
                  id="dark-mode"
                  checked={darkMode}
                  onCheckedChange={setDarkMode}
                />
              </div>
            </CardContent>
          </Card>

          {/* Notifications */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center">
                <Bell className="w-4 h-4 mr-2" />
                Notifications
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="notifications" className="text-sm">Enable Notifications</Label>
                  <p className="text-xs text-gray-500">Get notified when timers complete</p>
                </div>
                <Switch
                  id="notifications"
                  checked={notifications}
                  onCheckedChange={setNotifications}
                />
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="sounds" className="text-sm">Sound Effects</Label>
                  <p className="text-xs text-gray-500">Play sounds for timer events</p>
                </div>
                <Switch
                  id="sounds"
                  checked={sounds}
                  onCheckedChange={setSounds}
                />
              </div>
            </CardContent>
          </Card>

          {/* Focus Mode */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center">
                <Shield className="w-4 h-4 mr-2" />
                Focus Mode
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="strict-mode" className="text-sm">Strict Lock Mode</Label>
                  <p className="text-xs text-gray-500">Prevent navigation during focus sessions</p>
                </div>
                <Switch
                  id="strict-mode"
                  checked={strictMode}
                  onCheckedChange={setStrictMode}
                />
              </div>
            </CardContent>
          </Card>

          {/* Timer Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center">
                <Clock className="w-4 h-4 mr-2" />
                Timer Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-3 text-sm">
                <div className="text-center">
                  <div className="font-medium text-gray-900">Focus</div>
                  <div className="text-gray-500">25 min</div>
                </div>
                <div className="text-center">
                  <div className="font-medium text-gray-900">Break</div>
                  <div className="text-gray-500">5 min</div>
                </div>
                <div className="text-center">
                  <div className="font-medium text-gray-900">Long Break</div>
                  <div className="text-gray-500">15 min</div>
                </div>
              </div>
              <p className="text-xs text-gray-500 text-center">
                Timer durations are currently fixed but can be customized in future updates
              </p>
            </CardContent>
          </Card>

          {/* Data Management */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center">
                <Download className="w-4 h-4 mr-2" />
                Data Management
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={handleExportData}
              >
                <Download className="w-4 h-4 mr-2" />
                Export Data
              </Button>
              
              <Button
                variant="outline"
                className="w-full justify-start text-red-600 border-red-200 hover:bg-red-50"
                onClick={handleClearData}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Clear All Data
              </Button>
            </CardContent>
          </Card>

          {/* About */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">About Focus Flow</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600 space-y-2">
                <p>Version 1.0.0</p>
                <p>A productivity app inspired by the Pomodoro Technique to help you focus and manage tasks effectively.</p>
                <p className="text-xs text-gray-500 mt-4">
                  Built with React, TypeScript, and Tailwind CSS
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-30">
        <div className="max-w-md mx-auto px-4">
          <div className="flex justify-around py-2">
            <Link href="/">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <Clock className="w-5 h-5 mb-1" />
                <span className="text-xs">Timer</span>
              </div>
            </Link>
            <Link href="/tasks">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <TasksIcon className="w-5 h-5 mb-1" />
                <span className="text-xs">Tasks</span>
              </div>
            </Link>
            <Link href="/wellness">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <Heart className="w-5 h-5 mb-1" />
                <span className="text-xs">Wellness</span>
              </div>
            </Link>
            <Link href="/stats">
              <div className="flex flex-col items-center py-2 px-3 text-gray-400 hover:text-gray-600 transition-colors">
                <BarChart3 className="w-5 h-5 mb-1" />
                <span className="text-xs">Stats</span>
              </div>
            </Link>
            <Link href="/settings">
              <div className="flex flex-col items-center py-2 px-3 text-primary">
                <SettingsIcon className="w-5 h-5 mb-1" />
                <span className="text-xs font-medium">Settings</span>
              </div>
            </Link>
          </div>
        </div>
      </nav>
    </div>
  );
}
