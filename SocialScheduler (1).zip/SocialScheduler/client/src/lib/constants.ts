export const TIMER_MODES = {
  FOCUS: 'focus',
  BREAK: 'break',
  LONG_BREAK: 'long-break',
} as const;

export const TIMER_DURATIONS = {
  [TIMER_MODES.FOCUS]: 25,
  [TIMER_MODES.BREAK]: 5,
  [TIMER_MODES.LONG_BREAK]: 15,
} as const;

export const TASK_PRIORITIES = {
  LOW: 'Low',
  MEDIUM: 'Medium',
  HIGH: 'High',
} as const;

export const TASK_CATEGORIES = [
  'Work',
  'Personal',
  'Meeting',
  'Learning',
  'Health',
  'Other',
] as const;

export const MOTIVATIONAL_QUOTES = [
  "Stay focused! The successful warrior is the average person with laser-like focus.",
  "Focus is not just about what you concentrate on, but what you choose to ignore.",
  "Where attention goes, energy flows and results show.",
  "The art of being wise is knowing what to overlook.",
  "Concentrate all your thoughts upon the work at hand.",
  "Success is the result of preparation, hard work, and focus.",
] as const;

export const SOUND_NOTIFICATIONS = {
  TIMER_COMPLETE: '/sounds/timer-complete.mp3',
  TIMER_TICK: '/sounds/timer-tick.mp3',
  TASK_COMPLETE: '/sounds/task-complete.mp3',
} as const;
