import { useQuery } from '@tanstack/react-query';
import type { YouTubeVideo, YouTubePlaylist } from '@shared/schema';

export function useYouTubeSearch(query?: string, category?: string, type: 'video' | 'playlist' | 'live' = 'video') {
  return useQuery({
    queryKey: ['/api/youtube/search', { q: query, category, type }],
    enabled: !!(query || category),
  });
}

export function useYouTubePlaylists() {
  return useQuery({
    queryKey: ['/api/youtube/playlists'],
  });
}

export function useYouTubeLiveStreams() {
  return useQuery({
    queryKey: ['/api/youtube/live'],
    refetchInterval: 5 * 60 * 1000, // Refetch every 5 minutes
  });
}

export function useYouTubeCategories() {
  return useQuery({
    queryKey: ['/api/youtube/categories'],
  });
}

export function useHealthVideos(category?: string) {
  return useQuery({
    queryKey: ['/api/youtube/search', { category, type: 'video' }],
    enabled: !!category,
  });
}