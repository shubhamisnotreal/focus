import { useState, useEffect, useRef, useCallback } from 'react';
import { TIMER_MODES, TIMER_DURATIONS, MOTIVATIONAL_QUOTES } from '@/lib/constants';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export type TimerMode = keyof typeof TIMER_DURATIONS;

interface TimerState {
  minutes: number;
  seconds: number;
  isRunning: boolean;
  mode: TimerMode;
  session: number;
  isLocked: boolean;
  currentSessionId: number | null;
}

export function useTimer(currentTaskId?: number) {
  const [timer, setTimer] = useState<TimerState>({
    minutes: TIMER_DURATIONS[TIMER_MODES.FOCUS],
    seconds: 0,
    isRunning: false,
    mode: TIMER_MODES.FOCUS,
    session: 1,
    isLocked: false,
    currentSessionId: null,
  });

  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const createSessionMutation = useMutation({
    mutationFn: async (data: { type: string; duration: number; taskId?: number }) => {
      const response = await apiRequest('POST', '/api/sessions', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sessions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
  });

  const completeSessionMutation = useMutation({
    mutationFn: async (sessionId: number) => {
      const response = await apiRequest('PATCH', `/api/sessions/${sessionId}/complete`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sessions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
  });

  const startTimer = useCallback(async () => {
    try {
      const session = await createSessionMutation.mutateAsync({
        type: timer.mode,
        duration: TIMER_DURATIONS[timer.mode],
        taskId: currentTaskId,
      });

      setTimer(prev => ({
        ...prev,
        isRunning: true,
        currentSessionId: session.id,
        isLocked: timer.mode === TIMER_MODES.FOCUS,
      }));

      intervalRef.current = setInterval(() => {
        setTimer(prev => {
          if (prev.seconds === 0) {
            if (prev.minutes === 0) {
              // Timer finished
              completeTimer();
              return prev;
            }
            return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
          }
          return { ...prev, seconds: prev.seconds - 1 };
        });
      }, 1000);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to start timer session",
        variant: "destructive",
      });
    }
  }, [timer.mode, currentTaskId, createSessionMutation, toast]);

  const pauseTimer = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setTimer(prev => ({ ...prev, isRunning: false, isLocked: false }));
  }, []);

  const resetTimer = useCallback(() => {
    pauseTimer();
    setTimer(prev => ({
      ...prev,
      minutes: TIMER_DURATIONS[prev.mode],
      seconds: 0,
      currentSessionId: null,
    }));
  }, [pauseTimer]);

  const completeTimer = useCallback(async () => {
    pauseTimer();
    
    if (timer.currentSessionId) {
      try {
        await completeSessionMutation.mutateAsync(timer.currentSessionId);
        
        const isBreak = timer.mode !== TIMER_MODES.FOCUS;
        const nextMode = isBreak ? TIMER_MODES.FOCUS : 
          (timer.session % 4 === 0 ? TIMER_MODES.LONG_BREAK : TIMER_MODES.BREAK);
        
        setTimer(prev => ({
          ...prev,
          mode: nextMode,
          minutes: TIMER_DURATIONS[nextMode],
          seconds: 0,
          session: isBreak ? prev.session : prev.session + 1,
          currentSessionId: null,
        }));

        toast({
          title: "Timer Complete!",
          description: isBreak ? "Break time is over. Ready to focus?" : "Focus session complete. Time for a break!",
        });

        // Play notification sound (if available)
        try {
          const audio = new Audio('/sounds/timer-complete.mp3');
          audio.play().catch(() => {
            // Silently fail if audio can't play
          });
        } catch {
          // Silently fail if audio not available
        }
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to complete timer session",
          variant: "destructive",
        });
      }
    }
  }, [pauseTimer, timer.currentSessionId, timer.mode, timer.session, completeSessionMutation, toast]);

  const skipTimer = useCallback(() => {
    completeTimer();
  }, [completeTimer]);

  const setMode = useCallback((mode: TimerMode) => {
    if (timer.isRunning) return;
    
    setTimer(prev => ({
      ...prev,
      mode,
      minutes: TIMER_DURATIONS[mode],
      seconds: 0,
    }));
  }, [timer.isRunning]);

  const toggleTimer = useCallback(() => {
    if (timer.isRunning) {
      pauseTimer();
    } else {
      startTimer();
    }
  }, [timer.isRunning, pauseTimer, startTimer]);

  const emergencyUnlock = useCallback(() => {
    pauseTimer();
    setTimer(prev => ({ ...prev, isLocked: false }));
    toast({
      title: "Session Interrupted",
      description: "Your focus session has been paused.",
      variant: "destructive",
    });
  }, [pauseTimer, toast]);

  const getDisplayTime = useCallback(() => {
    return `${timer.minutes.toString().padStart(2, '0')}:${timer.seconds.toString().padStart(2, '0')}`;
  }, [timer.minutes, timer.seconds]);

  const getProgress = useCallback(() => {
    const totalSeconds = TIMER_DURATIONS[timer.mode] * 60;
    const currentSeconds = timer.minutes * 60 + timer.seconds;
    return (totalSeconds - currentSeconds) / totalSeconds;
  }, [timer.mode, timer.minutes, timer.seconds]);

  const getMotivationalQuote = useCallback(() => {
    return MOTIVATIONAL_QUOTES[Math.floor(Math.random() * MOTIVATIONAL_QUOTES.length)];
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  // Prevent tab switching when locked (browser limitation workaround)
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (timer.isLocked && document.hidden) {
        toast({
          title: "Stay Focused!",
          description: "Please return to your focus session.",
        });
      }
    };

    if (timer.isLocked) {
      document.addEventListener('visibilitychange', handleVisibilityChange);
    }

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [timer.isLocked, toast]);

  return {
    ...timer,
    toggleTimer,
    resetTimer,
    skipTimer,
    setMode,
    emergencyUnlock,
    getDisplayTime,
    getProgress,
    getMotivationalQuote,
  };
}
