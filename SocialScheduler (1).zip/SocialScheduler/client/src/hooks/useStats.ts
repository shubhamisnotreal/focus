import { useQuery } from '@tanstack/react-query';
import type { UserStats } from '@shared/schema';

export function useStats() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['/api/stats'],
  });

  return {
    stats: stats as UserStats | undefined,
    isLoading,
  };
}
