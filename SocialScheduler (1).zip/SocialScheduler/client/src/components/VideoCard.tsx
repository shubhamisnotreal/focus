import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Play, Clock, Eye, Radio } from 'lucide-react';
import type { YouTubeVideo } from '@shared/schema';

interface VideoCardProps {
  video: YouTubeVideo;
  onClick?: () => void;
}

export default function VideoCard({ video, onClick }: VideoCardProps) {
  const formatDuration = (duration?: string) => {
    if (!duration) return '';
    
    // Parse ISO 8601 duration (PT4M13S -> 4:13)
    const match = duration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
    if (!match) return '';
    
    const hours = parseInt(match[1] || '0');
    const minutes = parseInt(match[2] || '0');
    const seconds = parseInt(match[3] || '0');
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const formatViewCount = (viewCount?: string) => {
    if (!viewCount) return '';
    
    const count = parseInt(viewCount);
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M views`;
    }
    if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K views`;
    }
    return `${count} views`;
  };

  return (
    <Card 
      className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
      onClick={onClick}
    >
      <div className="relative">
        <img
          src={video.thumbnail}
          alt={video.title}
          className="w-full aspect-video object-cover"
        />
        
        {/* Play button overlay */}
        <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-30 transition-opacity flex items-center justify-center">
          <div className="w-12 h-12 bg-white bg-opacity-90 rounded-full flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
            <Play className="w-6 h-6 text-gray-800 ml-1" />
          </div>
        </div>
        
        {/* Duration badge */}
        {video.duration && (
          <Badge 
            variant="secondary" 
            className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs"
          >
            <Clock className="w-3 h-3 mr-1" />
            {formatDuration(video.duration)}
          </Badge>
        )}
        
        {/* Live badge */}
        {video.isLive && (
          <Badge 
            variant="destructive" 
            className="absolute top-2 left-2 bg-red-600 text-white text-xs animate-pulse"
          >
            <Radio className="w-3 h-3 mr-1" />
            LIVE
          </Badge>
        )}
      </div>
      
      <CardContent className="p-4">
        <h3 className="font-medium text-sm line-clamp-2 mb-2 text-gray-900">
          {video.title}
        </h3>
        
        <div className="space-y-1 text-xs text-gray-500">
          <p className="truncate">{video.channelTitle}</p>
          
          <div className="flex items-center space-x-3">
            {video.viewCount && (
              <div className="flex items-center">
                <Eye className="w-3 h-3 mr-1" />
                {formatViewCount(video.viewCount)}
              </div>
            )}
            
            <div>
              {new Date(video.publishedAt).toLocaleDateString()}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}