import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PlayCircle, List } from 'lucide-react';
import type { YouTubePlaylist } from '@shared/schema';

interface PlaylistCardProps {
  playlist: YouTubePlaylist;
  onClick?: () => void;
}

export default function PlaylistCard({ playlist, onClick }: PlaylistCardProps) {
  const getCategoryColor = (category: string) => {
    const colors = {
      meditation: 'bg-purple-100 text-purple-700',
      yoga: 'bg-green-100 text-green-700',
      nutrition: 'bg-orange-100 text-orange-700',
      sleep: 'bg-blue-100 text-blue-700',
      wellness: 'bg-pink-100 text-pink-700'
    };
    return colors[category as keyof typeof colors] || 'bg-gray-100 text-gray-700';
  };

  return (
    <Card 
      className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
      onClick={onClick}
    >
      <div className="relative">
        <img
          src={playlist.thumbnail}
          alt={playlist.title}
          className="w-full aspect-video object-cover"
        />
        
        {/* Playlist overlay */}
        <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-30 transition-opacity flex items-center justify-center">
          <div className="w-16 h-16 bg-white bg-opacity-90 rounded-full flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
            <PlayCircle className="w-8 h-8 text-gray-800" />
          </div>
        </div>
        
        {/* Video count badge */}
        <Badge 
          variant="secondary" 
          className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs"
        >
          <List className="w-3 h-3 mr-1" />
          {playlist.videoCount || 'Playlist'}
        </Badge>
        
        {/* Category badge */}
        <Badge 
          className={`absolute top-2 left-2 text-xs ${getCategoryColor(playlist.category)}`}
        >
          {playlist.category}
        </Badge>
      </div>
      
      <CardContent className="p-4">
        <h3 className="font-medium text-sm line-clamp-2 mb-2 text-gray-900">
          {playlist.title}
        </h3>
        
        <div className="space-y-1 text-xs text-gray-500">
          <p className="truncate">{playlist.channelTitle}</p>
          {playlist.description && (
            <p className="line-clamp-2 text-gray-400">
              {playlist.description}
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}