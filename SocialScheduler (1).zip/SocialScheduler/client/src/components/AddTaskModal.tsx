import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { TASK_CATEGORIES, TASK_PRIORITIES } from '@/lib/constants';
import type { Task, InsertTask } from '@shared/schema';

interface AddTaskModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (task: InsertTask) => void;
  editingTask?: Task;
  isLoading?: boolean;
}

export default function AddTaskModal({
  open,
  onOpenChange,
  onSubmit,
  editingTask,
  isLoading = false,
}: AddTaskModalProps) {
  const [title, setTitle] = useState(editingTask?.title || '');
  const [category, setCategory] = useState(editingTask?.category || 'Work');
  const [priority, setPriority] = useState(editingTask?.priority || 'Medium');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onSubmit({
      title: title.trim(),
      category,
      priority,
    });

    if (!editingTask) {
      setTitle('');
      setCategory('Work');
      setPriority('Medium');
    }
  };

  const priorityButtons = [
    { value: TASK_PRIORITIES.LOW, label: 'Low', color: 'border-blue-200 text-blue-600 hover:bg-blue-50' },
    { value: TASK_PRIORITIES.MEDIUM, label: 'Medium', color: 'border-yellow-200 text-yellow-600 hover:bg-yellow-50' },
    { value: TASK_PRIORITIES.HIGH, label: 'High', color: 'border-red-200 text-red-600 hover:bg-red-50' },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {editingTask ? 'Edit Task' : 'Add New Task'}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="title">Task Title</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter task title..."
              required
            />
          </div>
          
          <div>
            <Label htmlFor="category">Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TASK_CATEGORIES.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label>Priority</Label>
            <div className="flex space-x-2 mt-2">
              {priorityButtons.map((p) => (
                <Button
                  key={p.value}
                  type="button"
                  variant="outline"
                  size="sm"
                  className={`flex-1 ${p.color} ${priority === p.value ? 'bg-opacity-20' : ''}`}
                  onClick={() => setPriority(p.value)}
                >
                  {p.label}
                </Button>
              ))}
            </div>
          </div>
          
          <div className="flex space-x-3 pt-4">
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1"
              disabled={!title.trim() || isLoading}
            >
              {isLoading ? 'Saving...' : (editingTask ? 'Update Task' : 'Add Task')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
