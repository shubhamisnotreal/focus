import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import CircularTimer from './CircularTimer';
import { useTimer } from '@/hooks/useTimer';
import { useTasks } from '@/hooks/useTasks';

export default function LockScreen() {
  const { getDisplayTime, getProgress, mode, getMotivationalQuote, emergencyUnlock } = useTimer();
  const { tasks } = useTasks();
  
  const currentTask = tasks.find(task => !task.completed);
  const quote = getMotivationalQuote();
  
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-primary to-red-600 z-50 animate-fade-in">
      <div className="flex flex-col items-center justify-center h-full text-white p-8">
        
        {/* Timer Display */}
        <div className="text-center mb-8">
          <CircularTimer
            progress={getProgress()}
            size={250}
            strokeWidth={8}
            className="mb-6 animate-pulse-slow"
          >
            <div className="text-4xl font-bold mb-2">{getDisplayTime()}</div>
            <div className="text-sm opacity-80 capitalize">
              {mode.replace('-', ' ')} Session
            </div>
          </CircularTimer>
        </div>

        {/* Motivational Message */}
        <div className="text-center mb-8 max-w-sm">
          <div className="text-xl font-medium mb-2">Stay Focused! 🎯</div>
          <div className="text-sm opacity-90 italic">"{quote}"</div>
        </div>

        {/* Current Task Display */}
        {currentTask && (
          <Card className="bg-white/10 backdrop-blur-sm border-white/20 p-6 mb-8 w-full max-w-sm">
            <div className="text-sm opacity-80 mb-2">Working on:</div>
            <div className="font-semibold text-lg text-white">
              {currentTask.title}
            </div>
            <div className="text-xs opacity-70 mt-1">
              {currentTask.category} • {currentTask.priority} Priority
            </div>
          </Card>
        )}

        {/* Emergency Unlock Button */}
        <Button
          variant="outline"
          className="bg-white/20 hover:bg-white/30 backdrop-blur-sm border-white/30 text-white"
          onClick={() => {
            const confirmed = window.confirm(
              "Are you sure you want to break your focus session? This will end your current session."
            );
            if (confirmed) {
              emergencyUnlock();
            }
          }}
        >
          Emergency Unlock
        </Button>
      </div>
    </div>
  );
}
