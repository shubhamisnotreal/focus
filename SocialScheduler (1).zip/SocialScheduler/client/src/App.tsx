import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Timer from "@/pages/Timer";
import Tasks from "@/pages/Tasks";
import Wellness from "@/pages/Wellness";
import Stats from "@/pages/Stats";
import Settings from "@/pages/Settings";
import NotFound from "@/pages/not-found";
import { useState } from "react";
import LockScreen from "@/components/LockScreen";
import { useTimer } from "@/hooks/useTimer";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Timer} />
      <Route path="/tasks" component={Tasks} />
      <Route path="/wellness" component={Wellness} />
      <Route path="/stats" component={Stats} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const { isLocked } = useTimer();

  return (
    <div className="min-h-screen bg-gray-50">
      <Router />
      {isLocked && <LockScreen />}
      <Toaster />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AppContent />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
