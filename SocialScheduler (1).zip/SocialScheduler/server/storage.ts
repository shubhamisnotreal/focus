import { tasks, focusSessions, userStats, type Task, type InsertTask, type FocusSession, type InsertFocusSession, type UserStats, type InsertUserStats } from "@shared/schema";

export interface IStorage {
  // Tasks
  getTasks(): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, updates: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;
  toggleTaskCompletion(id: number): Promise<Task | undefined>;

  // Focus Sessions
  getFocusSessions(): Promise<FocusSession[]>;
  createFocusSession(session: InsertFocusSession): Promise<FocusSession>;
  completeFocusSession(id: number): Promise<FocusSession | undefined>;
  getTodaysSessions(): Promise<FocusSession[]>;

  // User Stats
  getUserStats(): Promise<UserStats>;
  updateUserStats(updates: Partial<InsertUserStats>): Promise<UserStats>;
  incrementFocusSession(): Promise<UserStats>;
  incrementTaskCompleted(): Promise<UserStats>;
  updateStreak(): Promise<UserStats>;
}

export class MemStorage implements IStorage {
  private tasks: Map<number, Task>;
  private focusSessions: Map<number, FocusSession>;
  private userStats: UserStats;
  private currentTaskId: number;
  private currentSessionId: number;

  constructor() {
    this.tasks = new Map();
    this.focusSessions = new Map();
    this.userStats = {
      id: 1,
      focusSessionsToday: 0,
      tasksCompletedToday: 0,
      currentStreak: 0,
      totalFocusTime: 0,
      lastActiveDate: new Date(),
    };
    this.currentTaskId = 1;
    this.currentSessionId = 1;
  }

  // Tasks
  async getTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.currentTaskId++;
    const task: Task = {
      id,
      title: insertTask.title,
      category: insertTask.category || 'Work',
      priority: insertTask.priority || 'Medium',
      completed: insertTask.completed || false,
      createdAt: new Date(),
    };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(id: number, updates: Partial<InsertTask>): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;

    const updatedTask = { ...task, ...updates };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }

  async deleteTask(id: number): Promise<boolean> {
    return this.tasks.delete(id);
  }

  async toggleTaskCompletion(id: number): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;

    const updatedTask = { ...task, completed: !task.completed };
    this.tasks.set(id, updatedTask);
    
    if (updatedTask.completed) {
      await this.incrementTaskCompleted();
    }
    
    return updatedTask;
  }

  // Focus Sessions
  async getFocusSessions(): Promise<FocusSession[]> {
    return Array.from(this.focusSessions.values()).sort((a, b) => 
      new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime()
    );
  }

  async createFocusSession(insertSession: InsertFocusSession): Promise<FocusSession> {
    const id = this.currentSessionId++;
    const session: FocusSession = {
      id,
      type: insertSession.type,
      duration: insertSession.duration,
      completed: insertSession.completed || false,
      taskId: insertSession.taskId || null,
      startedAt: new Date(),
      completedAt: null,
    };
    this.focusSessions.set(id, session);
    return session;
  }

  async completeFocusSession(id: number): Promise<FocusSession | undefined> {
    const session = this.focusSessions.get(id);
    if (!session) return undefined;

    const completedSession = {
      ...session,
      completed: true,
      completedAt: new Date(),
    };
    this.focusSessions.set(id, completedSession);

    if (session.type === 'focus') {
      await this.incrementFocusSession();
      this.userStats.totalFocusTime += session.duration;
    }

    return completedSession;
  }

  async getTodaysSessions(): Promise<FocusSession[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return Array.from(this.focusSessions.values()).filter(session => 
      new Date(session.startedAt) >= today
    );
  }

  // User Stats
  async getUserStats(): Promise<UserStats> {
    await this.updateDailyStats();
    return this.userStats;
  }

  async updateUserStats(updates: Partial<InsertUserStats>): Promise<UserStats> {
    this.userStats = { ...this.userStats, ...updates };
    return this.userStats;
  }

  async incrementFocusSession(): Promise<UserStats> {
    this.userStats.focusSessionsToday++;
    await this.updateStreak();
    return this.userStats;
  }

  async incrementTaskCompleted(): Promise<UserStats> {
    this.userStats.tasksCompletedToday++;
    return this.userStats;
  }

  async updateStreak(): Promise<UserStats> {
    const lastActive = new Date(this.userStats.lastActiveDate);
    const today = new Date();
    const diffDays = Math.floor((today.getTime() - lastActive.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays === 0) {
      // Same day, maintain streak
    } else if (diffDays === 1) {
      // Next day, increment streak
      this.userStats.currentStreak++;
    } else {
      // Gap in days, reset streak
      this.userStats.currentStreak = 1;
    }

    this.userStats.lastActiveDate = today;
    return this.userStats;
  }

  private async updateDailyStats(): Promise<void> {
    const lastActive = new Date(this.userStats.lastActiveDate);
    const today = new Date();
    
    // Reset daily stats if it's a new day
    if (lastActive.toDateString() !== today.toDateString()) {
      this.userStats.focusSessionsToday = 0;
      this.userStats.tasksCompletedToday = 0;
      this.userStats.lastActiveDate = today;
    }
  }
}

export const storage = new MemStorage();
