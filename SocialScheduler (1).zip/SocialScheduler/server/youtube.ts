import type { YouTubeVideo, YouTubePlaylist, YouTubeSearchParams } from '@shared/schema';

const YOUTUBE_API_KEY = process.env.YOUTUBE_API_KEY;
const YOUTUBE_BASE_URL = 'https://www.googleapis.com/youtube/v3';

// Health and wellness categories with specific search terms
export const HEALTH_CATEGORIES = {
  meditation: {
    name: 'Meditation & Mindfulness',
    queries: ['guided meditation', 'mindfulness meditation', 'breathing exercises', 'stress relief meditation']
  },
  yoga: {
    name: 'Yoga & Stretching',
    queries: ['yoga for beginners', 'morning yoga', 'desk yoga', 'yoga stretches']
  },
  fitness: {
    name: 'Fitness & Exercise',
    queries: ['home workout', 'cardio exercise', 'strength training', 'quick workout']
  },
  nutrition: {
    name: 'Nutrition & Healthy Eating',
    queries: ['healthy recipes', 'nutrition tips', 'meal prep', 'healthy cooking']
  },
  sleep: {
    name: 'Sleep & Relaxation',
    queries: ['sleep meditation', 'bedtime stories', 'relaxing music', 'sleep sounds']
  },
  mentalhealth: {
    name: 'Mental Health & Wellness',
    queries: ['stress management', 'anxiety relief', 'mental wellness', 'self care tips']
  }
} as const;

export class YouTubeService {
  private async makeRequest(endpoint: string, params: Record<string, string>) {
    if (!YOUTUBE_API_KEY) {
      throw new Error('YouTube API key not configured');
    }

    const url = new URL(`${YOUTUBE_BASE_URL}/${endpoint}`);
    url.searchParams.append('key', YOUTUBE_API_KEY);
    
    Object.entries(params).forEach(([key, value]) => {
      url.searchParams.append(key, value);
    });

    const response = await fetch(url.toString());
    
    if (!response.ok) {
      throw new Error(`YouTube API error: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  async searchVideos(searchParams: YouTubeSearchParams): Promise<YouTubeVideo[]> {
    const { query, category, type = 'video', maxResults = 12 } = searchParams;
    
    let searchQuery = query;
    
    // If category is specified, use predefined health queries
    if (category && HEALTH_CATEGORIES[category as keyof typeof HEALTH_CATEGORIES]) {
      const categoryData = HEALTH_CATEGORIES[category as keyof typeof HEALTH_CATEGORIES];
      const randomQuery = categoryData.queries[Math.floor(Math.random() * categoryData.queries.length)];
      searchQuery = query ? `${query} ${randomQuery}` : randomQuery;
    }

    // Default to health-related content if no query specified
    if (!searchQuery) {
      searchQuery = 'health wellness mindfulness';
    }

    const params: Record<string, string> = {
      part: 'snippet',
      type: type,
      q: searchQuery,
      maxResults: maxResults.toString(),
      order: 'relevance',
      safeSearch: 'strict',
      regionCode: 'US'
    };

    // Add live event filter if searching for live streams
    if (type === 'live') {
      params.eventType = 'live';
      params.type = 'video';
    }

    const data = await this.makeRequest('search', params);

    return data.items.map((item: any) => ({
      id: item.id.videoId || item.id.playlistId,
      title: item.snippet.title,
      description: item.snippet.description,
      thumbnail: item.snippet.thumbnails.medium?.url || item.snippet.thumbnails.default.url,
      channelTitle: item.snippet.channelTitle,
      publishedAt: item.snippet.publishedAt,
      isLive: item.snippet.liveBroadcastContent === 'live'
    }));
  }

  async getVideoDetails(videoIds: string[]): Promise<YouTubeVideo[]> {
    if (videoIds.length === 0) return [];

    const params = {
      part: 'snippet,contentDetails,statistics',
      id: videoIds.join(',')
    };

    const data = await this.makeRequest('videos', params);

    return data.items.map((item: any) => ({
      id: item.id,
      title: item.snippet.title,
      description: item.snippet.description,
      thumbnail: item.snippet.thumbnails.medium?.url || item.snippet.thumbnails.default.url,
      channelTitle: item.snippet.channelTitle,
      publishedAt: item.snippet.publishedAt,
      duration: item.contentDetails.duration,
      viewCount: item.statistics.viewCount,
      isLive: item.snippet.liveBroadcastContent === 'live'
    }));
  }

  async getHealthPlaylists(): Promise<YouTubePlaylist[]> {
    const playlists: YouTubePlaylist[] = [];
    
    // Search for curated health playlists
    const healthQueries = [
      'meditation playlist',
      'yoga workout playlist',
      'healthy cooking playlist',
      'sleep music playlist',
      'wellness tips playlist'
    ];

    for (const query of healthQueries) {
      try {
        const params = {
          part: 'snippet',
          type: 'playlist',
          q: query,
          maxResults: '3',
          order: 'relevance',
          safeSearch: 'strict'
        };

        const data = await this.makeRequest('search', params);
        
        const categoryPlaylists = data.items.map((item: any) => ({
          id: item.id.playlistId,
          title: item.snippet.title,
          description: item.snippet.description,
          thumbnail: item.snippet.thumbnails.medium?.url || item.snippet.thumbnails.default.url,
          channelTitle: item.snippet.channelTitle,
          videoCount: 0, // Will be populated separately if needed
          category: this.getCategoryFromQuery(query)
        }));

        playlists.push(...categoryPlaylists);
      } catch (error) {
        console.error(`Error fetching playlists for query "${query}":`, error);
      }
    }

    return playlists;
  }

  async getLiveStreams(): Promise<YouTubeVideo[]> {
    return this.searchVideos({
      query: 'wellness meditation yoga live',
      type: 'live',
      maxResults: 8
    });
  }

  private getCategoryFromQuery(query: string): string {
    if (query.includes('meditation')) return 'meditation';
    if (query.includes('yoga')) return 'yoga';
    if (query.includes('cooking')) return 'nutrition';
    if (query.includes('sleep')) return 'sleep';
    return 'wellness';
  }
}

export const youtubeService = new YouTubeService();