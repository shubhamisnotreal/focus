import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTaskSchema, insertFocusSessionSchema } from "@shared/schema";
import { youtubeService, HEALTH_CATEGORIES } from "./youtube";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Tasks routes
  app.get("/api/tasks", async (req, res) => {
    try {
      const tasks = await storage.getTasks();
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.post("/api/tasks", async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(taskData);
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid task data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create task" });
      }
    }
  });

  app.put("/api/tasks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = insertTaskSchema.partial().parse(req.body);
      const task = await storage.updateTask(id, updates);
      
      if (!task) {
        res.status(404).json({ message: "Task not found" });
        return;
      }
      
      res.json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid task data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update task" });
      }
    }
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteTask(id);
      
      if (!deleted) {
        res.status(404).json({ message: "Task not found" });
        return;
      }
      
      res.json({ message: "Task deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  app.patch("/api/tasks/:id/toggle", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const task = await storage.toggleTaskCompletion(id);
      
      if (!task) {
        res.status(404).json({ message: "Task not found" });
        return;
      }
      
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: "Failed to toggle task completion" });
    }
  });

  // Focus sessions routes
  app.get("/api/sessions", async (req, res) => {
    try {
      const sessions = await storage.getFocusSessions();
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sessions" });
    }
  });

  app.get("/api/sessions/today", async (req, res) => {
    try {
      const sessions = await storage.getTodaysSessions();
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch today's sessions" });
    }
  });

  app.post("/api/sessions", async (req, res) => {
    try {
      const sessionData = insertFocusSessionSchema.parse(req.body);
      const session = await storage.createFocusSession(sessionData);
      res.status(201).json(session);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid session data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create session" });
      }
    }
  });

  app.patch("/api/sessions/:id/complete", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const session = await storage.completeFocusSession(id);
      
      if (!session) {
        res.status(404).json({ message: "Session not found" });
        return;
      }
      
      res.json(session);
    } catch (error) {
      res.status(500).json({ message: "Failed to complete session" });
    }
  });

  // Stats routes
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getUserStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // YouTube routes
  app.get("/api/youtube/categories", async (req, res) => {
    try {
      res.json(HEALTH_CATEGORIES);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get("/api/youtube/search", async (req, res) => {
    try {
      const { q: query, category, type = 'video', maxResults = 12 } = req.query;
      
      const videos = await youtubeService.searchVideos({
        query: query as string,
        category: category as string,
        type: type as 'video' | 'playlist' | 'live',
        maxResults: parseInt(maxResults as string)
      });
      
      res.json(videos);
    } catch (error) {
      console.error('YouTube search error:', error);
      res.status(500).json({ message: "Failed to search videos" });
    }
  });

  app.get("/api/youtube/playlists", async (req, res) => {
    try {
      const playlists = await youtubeService.getHealthPlaylists();
      res.json(playlists);
    } catch (error) {
      console.error('YouTube playlists error:', error);
      res.status(500).json({ message: "Failed to fetch playlists" });
    }
  });

  app.get("/api/youtube/live", async (req, res) => {
    try {
      const liveStreams = await youtubeService.getLiveStreams();
      res.json(liveStreams);
    } catch (error) {
      console.error('YouTube live streams error:', error);
      res.status(500).json({ message: "Failed to fetch live streams" });
    }
  });

  app.get("/api/youtube/videos/:ids", async (req, res) => {
    try {
      const videoIds = req.params.ids.split(',');
      const videos = await youtubeService.getVideoDetails(videoIds);
      res.json(videos);
    } catch (error) {
      console.error('YouTube video details error:', error);
      res.status(500).json({ message: "Failed to fetch video details" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
