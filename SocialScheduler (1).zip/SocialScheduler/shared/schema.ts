import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull().default("Work"),
  priority: text("priority").notNull().default("Medium"), // Low, Medium, High
  completed: boolean("completed").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const focusSessions = pgTable("focus_sessions", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // focus, break, long-break
  duration: integer("duration").notNull(), // in minutes
  completed: boolean("completed").notNull().default(false),
  taskId: integer("task_id").references(() => tasks.id),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const userStats = pgTable("user_stats", {
  id: serial("id").primaryKey(),
  focusSessionsToday: integer("focus_sessions_today").notNull().default(0),
  tasksCompletedToday: integer("tasks_completed_today").notNull().default(0),
  currentStreak: integer("current_streak").notNull().default(0),
  totalFocusTime: integer("total_focus_time").notNull().default(0), // in minutes
  lastActiveDate: timestamp("last_active_date").notNull().defaultNow(),
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
});

export const insertFocusSessionSchema = createInsertSchema(focusSessions).omit({
  id: true,
  startedAt: true,
});

export const insertUserStatsSchema = createInsertSchema(userStats).omit({
  id: true,
});

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export type InsertFocusSession = z.infer<typeof insertFocusSessionSchema>;
export type FocusSession = typeof focusSessions.$inferSelect;

export type InsertUserStats = z.infer<typeof insertUserStatsSchema>;
export type UserStats = typeof userStats.$inferSelect;

// YouTube Integration Types
export interface YouTubeVideo {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  channelTitle: string;
  publishedAt: string;
  duration?: string;
  viewCount?: string;
  isLive?: boolean;
}

export interface YouTubePlaylist {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  channelTitle: string;
  videoCount: number;
  category: string;
}

export interface YouTubeSearchParams {
  query?: string;
  category?: string;
  type?: 'video' | 'playlist' | 'live';
  maxResults?: number;
}
